Features:

-CustomConfig (You can edit every message in NicknameChanger.yml)
-Logging system
-Coin Requirement
-Custom Commands

Commands:

nickname - Change your nickname with a cost of coins